const config = require('../config.json')

exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

  function helpMessage () {
    if (!args[0]) return message.delete() + message.channel.send("**Faite `%help bot`**")
    if (args[0]) {
      if (message.channel != message.author.dmChannel) message.delete() + message.channel.send('**L\'aide vous sera envoyée par message privé.**') + console.log("\n -Commande Help effectuer par " + message.author.tag)
    }
    if (args[0] == 'bot') {
      message.author.dmChannel.send('**__Bienvenue dans l\'aide du bot du Miroir Du Rised.__**\n\nLa première chose à faire est de vous enregistrer si vous ne l\'êtes pas déjà. Pour cela, utilisez ' + config.prefix +  `register` + '.\nVoici la liste des commandes disponibles. Pour de l\'aide sur une commande en particulier, utilisez `help <Commande>`.')
      return message.author.dmChannel.send('__**Joueurs**__\n\n\n`help` - Affiche l\'aide\n`register` - Enregistre le joueur dans la BDD du bot\n`unergister` - Permet de se unregister dans la BDD\n`point` - `help point` pour plus d\'informations \n`spell` - Faite `%help spell` pour plus d\'infomation.\n`find` - Afficher la fiche RP d\'une personne\n`afk` - Permet de se mettre AFK\n`userwarn` - Affiche les avertissements du joueur. \n\n\n__**Staff**_ \n`warn` - **(Commande staff)** - Avertit un joueur \n`unwarn` - **(Commande staff)** - Retire une avertissement à un joueur\n`purge` - **(Commande staff)** - Supprime plusieurs messages\n`mute` - **(Commande staff)** - Mute un joueur\n`unmute` - **(Commande staff)** - Unmute un joueur\n`mute-channel` - **(Commande staff)** - Mute un channel\n`unmute-channel` - **(Commande staff)** - Unmute un channel\n`kick` - **(Commande staff)** - Kick un joueur\n`ban` - **(Commande staff)** - Ban un joueur\n`userinfo` - **(Commande staff)** - Affiche des informations sur le joueur\n\n**Roll**\n\n`roll` - `help roll` pour plus d\'informations\n\n\n\n*Remerciement a bobwinibago#2451 pour son aide (Surtout de m\'avoir filer les fichier de son bot :3)*');
    } else
    if (args[0] == 'unregister') {
      return message.author.dmChannel.send('__**Unregister**__\n\n**Description :** Unregister un joueur dans la BDD du bot.\n**Usage :** `register`')
    } else
    if (args[0] == 'register') {
      return message.author.dmChannel.send('__**Register**__\n\n**Description :** Enregistre le joueur dans la BDD du bot.\n**Usage :** `register`')
    } else
    if (args[0] == 'find') {
      return message.author.dmChannel.send('__**Find**__\n\n**Description :** Afficher la fiche RP d\'une perssone\n**Usage :** `find <@Mention>`\n**Exemple :** `find TheZerbibi#2311`')
      } else
    if (args[0] == 'roll') {
      return message.author.dmChannel.send('__**Roll**__\n\n**Description :** J\'ai vraiment besoin de faire un dessin ?\n**Usage :** `roll <Roll>`\n**Exemple :** `roll d100` | `roll 2d25-10`\n**Note :** La couleur utilisée pour afficher le résultat varie selon celui-ci (vert pour une RC, bleu pour une réussite, orange pour un échec, rouge pour un EC)\n\nVoici comment procéder pour les rolls en cas de combat :\n\nhttps://media.discordapp.net/attachments/335773143702437890/398170782921916418/ROLL.png')
    } else
    if (args[0] == 'info') {
      return message.author.dmChannel.send('__**Info**__\n\n**Description :** Permet de voir les different role présent sur le Discord\n**Usage :** `info list` ')
    } else
    if (args[0] == 'afk') {
      return message.author.dmChannel.send('__**Afk**__\n\n**Description :** Permet de se mettre AFK\n**Usage :** `afk')
    } else
    if (args[0] == 'spell') {
      return message.author.dmChannel.send('__**Spell**__\n\n**Description :** Permet de faire une action lié a un sort.\n**Usage :**\n `%spell` **SI CE N\'EST PAS UN DUEL !**\n`%spell <@NomDeLadversaire>` **UNIQUEMENT EN DUEL OU CONTRE UNE PERSONNE !**')
    } else
    if (args[0] == 'point') {
      return message.author.dmChannel.send('__**Point**__\n\n**Description :** Permet de gerer les points de maison.\n**Usage :**\n `point` Afficher le tableau des points.\n\n `%point publish` *(A effectuer apres chaque cours par un professeur)*\n `%point reset`\n `%point remove/add Poufsouffle/Serdaigle/Serpentard/Gryffondor (nombre)` \n\n __**Exemple**__\n\n`%point add Poufsouffle 20`')
    } else
    if (args[0] == 'userwarn') {
      return message.author.dmChannel.send('__**Avertuser**__\n\n**Description :** Affiche les avertissements du joueur. Un joueur peut voir ses propres avertissements, mais pas ceux des autres.\n**Usage :** `avertuser <@Mention>`\n**Exemple :** `avertuser TheZerbibi#2311`')
    } else
    if (args[0] == 'help') {
      return message.author.dmChannel.send('__**Help**__\n\n**Description :** Affiche l\'aide.\n**Usage :** `help ~<Commande>`\n**Exemple :** `help` | `help bot` | `help roll`')
    } else
    if (args[0] == 'warn') {
      return message.author.dmChannel.send('__**Avert**__\n\n**Description :** Avertit un joueur. Si le joueur arrive à 3 avertissements, le joueur passe en LC, et au prochain avertissement, il sera kick.\n**Usage :** `avert <@Mention> [Raison]`\n**Exemple :** `avert TheZerbibi#2311 A sorti son bot sans l\'aide`')
    } else
    if (args[0] == 'unwarn') {
      return message.author.dmChannel.send('__**Unavert**__\n\n**Description :** Retire une avertissement à un joueur.\n**Usage :** `unavert <@Mention>`\n**Exemple :** `unavert TheZerbibi#2311`')
    } else
    if (args[0] == 'userinfo') {
      return message.author.dmChannel.send('__**Userinfo**__\n\n**Description :** Affiche des informations sur le joueur.\n**Usage :** `userinfo <@Mention>`\n**Exemple :** `userinfo TheZerbibi#2311`')
    } else
    if (args[0] == 'purge') {
      return message.author.dmChannel.send('__**Purge**__\n\n**Description :** Supprime plusieurs messages. Surtout utile pour faire le ménage d\'un channel.\n**Usage :** `purge <NombreDeMessages>`\n**Exemple :** `purge 20`')
    } else
    if (args[0] == 'mute') {
      return message.author.dmChannel.send('__**Mute**__\n\n**Description :** Mute un joueur. Il ne pourra plus écrire.\n**Usage :** `mute <@Mention>`\n**Exemple :** `mute TheZerbibi#2311`')
    } else
    if (args[0] == 'unmute') {
      return message.author.dmChannel.send('__**Unmute**__\n\n**Description :** Unmute un joueur. Annule les effets d\'un `mute`.\n**Usage :** `unmute <@Mention>`\n**Exemple :** `unmute TheZerbibi#2311`')
    }else
    if (args[0] == 'mute-channel') {
      return message.author.dmChannel.send('__**Mute-channel**__\n\n**Description :**Mute le channel dans lequel la commande a était faite.\n**Usage :** `mute-channel`')
    } else
    if (args[0] == 'unmute-channel') {
      return message.author.dmChannel.send('__**Unmute-channel**__\n\n**Description :**UnMute le channel dans lequel la commande a était faite.\n**Usage :** `unmute-channel`')
    } else
    if (args[0] == 'kick') {
      return message.author.dmChannel.send('__**Kick**__\n\n**Description :**Kick un joueur.\n**Usage :** `kick <@Mention> <Raison>`\n**Exemple :** `kick TheZerbibi#2311 Spam`')
    } else
    if (args[0] == 'ban') {
      return message.author.dmChannel.send('__**Ban**__\n\n**Description :**Bannir un joueur.\n**Usage :** `ban <@Mention> <Raison>`\n**Exemple :** `ban TheZerbibi#2311 Spam`')
    } else
      return message.channel.send('Commande inconnue. Utilisez plutot `' + config.prefix + 'help bot` pour la liste des commandes.')
  } 

  if (!message.author.dmChannel) {
    message.author.createDM().then(() => {
      helpMessage()
    })
  }
  if (message.author.dmChannel) helpMessage()
    } else
        return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}