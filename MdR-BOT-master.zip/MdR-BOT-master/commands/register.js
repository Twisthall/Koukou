const Discord = require('discord.js')
const fs = require('fs')
const fileExists = require('file-exists')
const config = require('../config.json')

exports.run = (client, message) => {

    if (message.guild.id == "333359639385210881") {

  const playerFilePath = `../players/${message.author.id}.json`
  const playerFilePathA = `./players/${message.author.id}.json`

  fileExists(playerFilePathA).then(exists => {
    if (exists) return message.delete(1000) + message.channel.send('Vous êtes déjà enregistré.')

    if (!exists) {
      let defaultPlayer = '{"username":"","imageURL":"","warns":0,"warn1":"Vide","warn1Author":"Aucun","warn2":"Vide","warn2Author":"Aucun","warn3":"Vide","warn3Author":"Aucun"}'
      fs.writeFile(playerFilePathA, defaultPlayer, (err) => {
        if (err) throw err
        if (!err) {
          const player = require(playerFilePath)

          player.username = message.author.username
          player.imageURL = message.author.avatarURL
          fs.writeFile(playerFilePathA, JSON.stringify(player), (err) => console.error)

          message.guild.channels.find("name", "mod-log").send('**Éxécuteur :** ' + message.author.username + ' (' + message.author.id + ')\n**Channel :** ' + message.channel.name + ' (' + message.channel.id + ')\n**Envoi :** ' + message.createdAt.toString() + '\n**Commande :** ' + message.content)

              //OutPut
    const output = new Discord.RichEmbed()
                .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                .setColor(0x00FF27)
                .setFooter("Fiche descriptive de " , client.user.avatarURL)
                .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                .setTimestamp()
                .addBlankField(true)
                .addField("Commande", message.content)
                .addField("Éxécuteur", message.author.username, true)
                .addField("Channel", message.channel.name)
                .addField("Date", message.createdAt.toString())

    client.channels.get("431238767471230976").send({embed: output});
        return message.delete(1000) + message.channel.send('**Vous vous êtes enregistré avec succès.**')
        }
      })
    }
  })    
    } else
return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.");
}