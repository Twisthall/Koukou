const Discord = require('discord.js')
const fs = require('fs')
const fileExists = require('file-exists')
delete require.cache[require.resolve('../config.json')]
const config = require('../config.json')

exports.run = (client, message) => {

    if (message.guild.id == "333359639385210881") {

    if (!message.member.hasPermission('KICK_MEMBERS')) {
        return  message.delete(1000) + message.reply("Vous ne disposez pas de la permission.")
    }
  
  let character = message.mentions.users.firstKey()

  if (!character) return message.delete(1000) + message.channel.send('Vous devez spécifier un personnes.')
    
  const playerFilePath = `../players/${character}.json`
  const playerFilePathA = `./players/${character}.json`

  fileExists(playerFilePathA).then(exists => {
    if (exists) return message.delete(1000) + message.channel.send('Cette personnes est déjà enregistré.')

    if (!exists) {
      let defaultPlayer = '{"username":"","warns":0,"warn1":"Vide","warn1Author":"Aucun","warn2":"Vide","warn2Author":"Aucun","warn3":"Vide","warn3Author":"Aucun"}'
      fs.writeFile(playerFilePathA, defaultPlayer, (err) => {
        if (err) throw err
        if (!err) {
          const player = require(playerFilePath)

          player.username = character
          fs.writeFile(playerFilePathA, JSON.stringify(player), (err) => console.error)

          message.guild.channels.find("name", "mod-log").send('**Éxécuteur :** ' + message.author.username + ' (' + message.author.id + ')\n**Channel :** ' + message.channel.name + ' (' + message.channel.id + ')\n**Envoi :** ' + message.createdAt.toString() + '\n**Commande :** ' + message.content)

    const output = new Discord.RichEmbed()
                .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                .setColor(0x00FF27)
                .setFooter("Fiche descriptive de " , client.user.avatarURL)
                .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                .setTimestamp()
                .addBlankField(true)
                .addField("Commande", message.content)
                .addField("Éxécuteur", message.author.username, true)
                .addField("Cible", '<@' + character + '>', true)
                .addField("Channel", message.channel.name)
                .addField("Date", message.createdAt.toString())
    
    client.channels.get("431238767471230976").send({embed: output});
        return message.delete(1000) + message.channel.send('**Cette personne a été enregistré avec succès.**')
        }
      })
    }
  })
  } else
return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.");
}