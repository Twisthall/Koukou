const config = require('../config.json')
const Discord = require('discord.js')

exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

    if (!message.member.hasPermission('KICK_MEMBERS')) {
      return message.delete(1000) + message.reply("Vous ne disposez pas de la permission.")
  }

let roleum = message.guild.roles.find("name", "Muted");
let unmute = message.mentions.members.first();

  if (!unmute) 
  return message.delete(1000) + message.reply("Merci de mentionner quelqu'un")

let muted = unmute.roles.some(r => ["Muted"].includes(r.name));
    
if (muted) {

      unmute.removeRole(roleum).catch(console.error);
  message.delete(1000)
  message.guild.channels.find("name", "hrp").send(`**${unmute.user}, vous avez ete unmute. Merci de ne plus vous faire remarquer.**`)
  message.guild.channels.find("name", "mod-log").send(`**UNMUTE**\n**User :**${unmute.user}\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)


      //OutPut
      const output = new Discord.RichEmbed()
      .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
      .setColor(0x74FF00)
      .setFooter("Fiche descriptive de " , client.user.avatarURL)
      .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
      .setTimestamp()
      .addBlankField(true)
      .addField("Commande", message.content)
      .addField("Éxécuteur", message.author.username, true)
      .addField("Cible", unmute.user, true)
      .addField("Channel", message.channel.name)
      .addField("Date", message.createdAt.toString())
      client.channels.get("431238767471230976").send({embed: output});
    
    } else
        return message.delete(1000) + message.channel.send("**Cette personne n'est actuellement pas mute !**");

    } else
        return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.");
}