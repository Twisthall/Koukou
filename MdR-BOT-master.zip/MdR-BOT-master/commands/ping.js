exports.run = (client, message) => {
  message.delete(1000);
  message.channel.send('Pong ! **' + client.pings[0] + ' ms**');
}