exports.run = (client, message, args) => {
    if (!args[0])
        return message.delete(1000) + message.channel.send("**Merci de spécifier la categorie dont vous voulez voir les roles\nFaite `%info list` pour voir les different éléments**");
    if (args[0] == 'list') {
        message.delete(1000);
        return message.channel.send("**Faite `%info <voir list>`, \n\n__Exemple :__\n`%info work` pour voir les roles présent sur le Discord**\n\n**La list :** `work`, `prof`, `eleves`, `annees`, `sang`, `race`, `faculte`, `pm`, `hrp`");
    }
    else if (args[0] == 'work') {
        message.delete(1000);
        return message.channel.send('__**Les métiers présent sur le Discord :**__\n\n**Les métiers :** `"Directeur de Poudlard"`, `"Directeur Adjoint de Poudlard"`, `"Professeur"`, `"Concierge"`, \n`"Fantôme"`, `"Garde Chasse"`, `"Surveillant"`, `"Infirmièr(e)"`, `"Bibliothécaire"`, `"Elèves"`');
    }
    else if (args[0] == 'sang') {
        message.delete(1000);
        return message.channel.send('__**Les sangs présent sur le Discord :**__\n\n `"Sangs-meles"`, `"Nés-Moldus"`, `"Sangs-purs"`, `"Hybride"`, `"Moldu"`');
    }
    else if (args[0] == 'race') {
        message.delete(1000);
        return message.channel.send('__**Les race présent sur le Discord :**__\n\n `"Velane"`, `"Lycan"`, `"Animagus"`, `"Vampire"`, `"Humain"`, `"Metamorphomage"`, `"Sorciers"`, `"Sorcieres"`');
    }
    else if (args[0] == 'faculte') {
        message.delete(1000);
        return message.channel.send('__**Les facultés présent sur le Discord :**__\n\n `"Legilimens"`, `"Occlumens"`');
    }
    else if (args[0] == 'pm') {
        message.delete(1000);
        return message.channel.send('__**Les puissances magiques présent sur le Discord :**__\n\n `"PM : 0"`, `"PM : 1"`, `"PM : 2"`, `"PM : 3"`, `"PM : 4"`, `"PM : 5"`, `"PM : 6"`, `"PM : 7"`, `"PM : 8"`, `"PM : 9"`, `"PM : 10"`');
    }
    else if (args[0] == 'hrp') {
        message.delete(1000);
        return message.channel.send('__**Les roles Hors-RP présent sur le Discord :**__\n\n `"Rôlistes"`, `"Spectateur"`, `"Sombral"`, `"Personnel Magique"`, `"Resp.Moderateurs"`, `"MJ"`, `"Scenariste"`,\n `"Encadrant"`, `"Moderateur"`, `"Resp.Scenaristes"`, `"Administrateur"`');
    }
    else if (args[0] == 'prof') {
        message.delete(1000);
        return message.channel.send('__**Les roles concernant les professeurs présent sur le Discord :**__\n\n `"DCFM"`, `"Botanique"`, `"Sortilèges"`, `"Métamorphose"`, `"Maître des potions"`, `"Astronomie"`,\n `"Histoire de la Magie"`, `"Arithmancie"`, `"Étude des runes"`, `"Étude des Goules"`, `"Étude des moldus"`, `"Soin des créatures Magiques"`, `"Alchimie"`, `"Divination"`, `"Directeur de maison"`');
    }
    else if (args[0] == 'eleves') {
        message.delete(1000);
        return message.channel.send('__**Les roles concernant les élèves présent sur le Discord :**__\n\n `"Serdaigle"`, `"Poufsouffle"`, `"Gryffondor"`, `"Serpentard"`, `"Préfets"`');
    }
    else if (args[0] == 'annees') {
        message.delete(1000);
        return message.channel.send('__**Les années d\'étude présent sur le Discord :**__\n\n `"Première Année"`');
    }
    return message.delete(1000) + message.channel.send("**Merci de spécifier la categorie dont vous voulez voir les roles\nFaite `%info list` pour voir les différent éléments**");
}