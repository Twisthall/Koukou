const fs = require('fs')
const fileExists = require('file-exists')
delete require.cache[require.resolve('../config.json')]
const config = require('../config.json')
const Discord = require('discord.js')

exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

  if (!message.member.hasPermission('KICK_MEMBERS')) {
    return message.reply("Vous ne disposez pas de la permission.")
        .then(message => console.log(`Reponse: ${message} \n---------------------------------------------------`))
}


  const playerFilePath = `../players/${message.author.id}.json`
  const playerFilePathA = `./players/${message.author.id}.json`

  fileExists(playerFilePathA).then(exists => {
    if (!exists) return message.channel.send('Vous devez être enregistré pour utiliser cette commande.')

    if (exists) {
      const player = require(playerFilePath)

      player.username = message.author.username
      player.imageURL = message.author.avatarURL
      fs.writeFile(playerFilePathA, JSON.stringify(player), (err) => console.error)

      let warnedUser = message.mentions.users.firstKey()

      const userFilePath = `../players/${warnedUser}.json`
      const userFilePathA = `./players/${warnedUser}.json`

      fileExists(userFilePathA).then(exists => {
        if (!exists) return message.channel.sendMessage('Ce joueur n\'est pas enregistré.')

        delete require.cache[require.resolve(userFilePath)]
        const user = require(userFilePath)

        if (user.warns == 3) {
          user.warns -= 1
          user.warn3 = 'Vide'
          user.warn3Author = 'Vide'
          fs.writeFile(userFilePathA, JSON.stringify(user), (err) => console.error)

          message.guild.channels.find("name", "mod-log").send('**Éxécuteur :** ' + message.author.username + ' (' + message.author.id + ')\n**Channel :** ' + message.channel.name + ' (' + message.channel.id + ')\n**Envoi :** ' + message.createdAt.toString() + '\n**Commande :** ' + message.content)

          return message.delete(1000) + message.channel.sendMessage('**Vous avez bien retiré un avertissement à <@' + warnedUser + '>**')
        } else
        if (user.warns == 2) {
          user.warns -= 1
          user.warn2 = 'Vide'
          user.warn2Author = 'Vide'
          fs.writeFile(userFilePathA, JSON.stringify(user), (err) => console.error)

          message.guild.channels.find("name", "mod-log").send('**Éxécuteur :** ' + message.author.username + ' (' + message.author.id + ')\n**Channel :** ' + message.channel.name + ' (' + message.channel.id + ')\n**Envoi :** ' + message.createdAt.toString() + '\n**Commande :** ' + message.content)

          return message.delete(1000) + message.channel.sendMessage('**Vous avez bien retiré un avertissement à <@' + warnedUser + '>**')
        } else
        if (user.warns == 1) {
          user.warns -= 1
          user.warn1 = 'Vide'
          user.warn1Author = 'Vide'
          fs.writeFile(userFilePathA, JSON.stringify(user), (err) => console.error)

          message.guild.channels.find("name", "mod-log").send('**Éxécuteur :** ' + message.author.username + ' (' + message.author.id + ')\n**Channel :** ' + message.channel.name + ' (' + message.channel.id + ')\n**Envoi :** ' + message.createdAt.toString() + '\n**Commande :** ' + message.content)

          return message.delete(1000) + message.channel.sendMessage('**Vous avez bien retiré un avertissement à <@' + warnedUser + '>**')
        } else
        if (user.warns == 0) {
          return message.channel.sendMessage('Ce joueur n\'a aucun avertissement.')
        }
      })

      //OutPut
    const output = new Discord.RichEmbed()
    .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setColor(0xFFA600)
    .setFooter("Fiche descriptive de " , client.user.avatarURL)
    .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setTimestamp()
    .addBlankField(true)
    .addField("Commande", message.content)
    .addField("Éxécuteur", message.author.username, true)
    .addField("Cible",'<@!' + warnedUser +'>', true)
    .addField("Channel", message.channel.name)
    .addField("Date", message.createdAt.toString())
    client.channels.get("431238767471230976").send({embed: output});

    }
  })
    } else
return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}