const fileExists = require('file-exists')

exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

  if (!message.member.hasPermission('KICK_MEMBERS')) {
    return message.reply("Vous ne disposez pas de la permission.")
        .then(message => console.log(`Reponse: ${message} \n---------------------------------------------------`))
}

  let warnUser = message.mentions.users.firstKey()

  if (warnUser == undefined) {
    return message.channel.send('Vous devez mentionner un utilisateur')
  } else

  if (warnUser != undefined) {
    const userFileName = warnUser
    const userFilePath = `../players/${userFileName}.json`
    const userFilePathA = `./players/${userFileName}.json`

    fileExists(userFilePathA).then(exists => {
      if (!exists) {
        return message.channel.send('Ce joueur n\'est pas enregistré.')
      } else

      if (exists) {
        delete require.cache[require.resolve(userFilePath)]
        const warnUserDisplay = require(userFilePath)

        let embedColor = 7506394
        if (warnUserDisplay.warns == 0) {
          embedColor = 4387906
        } else
        if (warnUserDisplay.warns == 1) {
          embedColor = 4342516
        } else
        if (warnUserDisplay.warns == 2) {
          embedColor = 16030530
        } else
        if (warnUserDisplay.warns == 3) {
          embedColor = 16007746
        }

        const warn1AuthorFilePath = `../players/${warnUserDisplay.warn1Author}.json`
        const warn2AuthorFilePath = `../players/${warnUserDisplay.warn2Author}.json`
        const warn3AuthorFilePath = `../players/${warnUserDisplay.warn3Author}.json`
        const warn1AuthorFilePathA = `./players/${warnUserDisplay.warn1Author}.json`
        const warn2AuthorFilePathA = `./players/${warnUserDisplay.warn2Author}.json`
        const warn3AuthorFilePathA = `./players/${warnUserDisplay.warn3Author}.json`
        let warn1AuthorName = 'Inconnu'
        let warn2AuthorName = 'Inconnu'
        let warn3AuthorName = 'Inconnu'

        fileExists(warn1AuthorFilePathA).then(exists => {
          if (exists) {
            delete require.cache[require.resolve(warn1AuthorFilePath)]
            const warn1Author = require(warn1AuthorFilePath)
            warn1AuthorName = warn1Author.username
          }
          fileExists(warn2AuthorFilePathA).then(exists => {
            if (exists) {
              delete require.cache[require.resolve(warn2AuthorFilePath)]
              const warn2Author = require(warn2AuthorFilePath)
              warn2AuthorName = warn2Author.username
            }
            fileExists(warn3AuthorFilePathA).then(exists => {
              if (exists) {
                delete require.cache[require.resolve(warn3AuthorFilePath)]
                const warn3Author = require(warn3AuthorFilePath)
                warn3AuthorName = warn3Author.username
              }

              return message.delete(1000) + message.channel.send(

                {
                  embed: {
                    color: embedColor,
                    author: {
                      name: 'Avertissements de ' + warnUserDisplay.username,
                      icon_url: warnUserDisplay.imageURL
                    },
                    description: "Nombre d'avertissements : `" + warnUserDisplay.warns + '`',
                    fields: [{
                      name: 'Avertissement 1',
                      value: 'Raison : `' + warnUserDisplay.warn1 + '`\nDonné par : `' + warn1AuthorName + '`'
                    },
                    {
                      name: 'Avertissement 2',
                      value: 'Raison : `' + warnUserDisplay.warn2 + '`\nDonné par : `' + warn2AuthorName + '`'
                    },
                    {
                      name: 'Avertissement 3',
                      value: 'Raison : `' + warnUserDisplay.warn3 + '`\nDonné par : `' + warn3AuthorName + '`'
                    }]
                  }
                }

          )
            })
          })
        })
      }
    })
  }
    } else
return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.");
}