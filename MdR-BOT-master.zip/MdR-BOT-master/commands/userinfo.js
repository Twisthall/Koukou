exports.run = (client, message, args) => {
  
    if (!message.member.hasPermission('KICK_MEMBERS')) {
      return message.reply("Vous ne disposez pas de la permission.")
          .then(message => console.log(`Reponse: ${message} \n---------------------------------------------------`))
  }
  
    let infoUser = message.mentions.members.first()
  
    if (infoUser == undefined) {
      return message.channel.send('Vous devez mentionner un utilisateur')
    } else
  
    if (infoUser != undefined) {
      let embedColor = infoUser.displayColor
  
      return message.channel.send(
  
        {
          embed: {
            color: embedColor,
            author: {
              name: 'Informations de ' + infoUser.user.username,
              icon_url: infoUser.user.avatarURL
            },
            fields: [{
              name: 'ID',
              value: infoUser.user.id,
              inline: true
            },
            {
              name: "Nom d'utilisateur",
              value: infoUser.user.username,
              inline: true
            },
            {
              name: 'Surnom',
              value: infoUser.displayName,
              inline: true
            },
            {
              name: 'Création du compte',
              value: infoUser.user.createdAt.toString(),
              inline: true
            },
            {
              name: 'Arrivée sur le serveur',
              value: infoUser.joinedAt.toString(),
              inline: true
            }
            ]
          }
        }
  
      )
    }
  }