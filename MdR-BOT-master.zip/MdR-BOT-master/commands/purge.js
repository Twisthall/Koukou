const config = require('../config.json')
const Discord = require('discord.js')

exports.run = (client, message, args) => {
  if (!message.member.hasPermission('KICK_MEMBERS')) {
  return message.delete(1000) + message.channel.send('Vous n\'avez pas la permission de faire cela.')
  }

  let amount = Number(args[0]) + 1

  if (amount == undefined) return message.channel.send('Vous devez entrer un nombre de messages à supprimer.')
  if (amount != parseInt(amount, 10) || amount < 0) return message.delete(1000) + message.channel.send('Vous devez entrer un nombre entier positif valide.')

    message.guild.channels.find("name", "mod-log").send('**Éxécuteur :** ' + message.author.username + ' (' + message.author.id + ')\n**Channel :** ' + message.channel.name + ' (' + message.channel.id + ')\n**Envoi :** ' + message.createdAt.toString() + '\n**Commande :** ' + message.content)

                  //OutPut
                  const output = new Discord.RichEmbed()
                  .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                  .setColor(0x00B6FF)
                  .setFooter("Fiche descriptive de " , client.user.avatarURL)
                  .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                  .setTimestamp()
                  .addBlankField(true)
                  .addField("Commande", message.content)
                  .addField("Éxécuteur", message.author.username, true)
                  .addField("Channel", message.channel.name)
                  .addField("Date", message.createdAt.toString())
                  client.channels.get("431238767471230976").send({embed: output});
  

  let deletedMessages = amount - 1

  message.channel.bulkDelete(amount)

  message.channel.send('**' + deletedMessages + ' messages ont bien été supprimés.**')
  .then(message => {
    client.user.lastMessage.delete(3000)
      })
  .catch(error => console.log(error));


  return
}