const Discord = require('discord.js')
exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

let character = message.mentions.members.first();
if (!character) return message.delete(1000) + message.reply("Merci de mentionner une personne.")

  //General
    let sang = character.roles.find(r => ["name", "Sang-mêlé", "Né-Moldu", "Sangs-purs", "Hybride"].includes(r.name)) || (" ");
    let sexe = character.roles.find(r => ["name", "Sorciers", "Sorcieres", "Moldus"].includes(r.name)) || (" ");
    let race = character.roles.find(r => ["name", "Velane", "Lycan", "Animagus", "Vampire", "Humains", "Metamorphomage"].includes(r.name)) || (" "); 
    let fac = character.roles.find(r => ["name", "Legilimens", "Occlumens"].includes(r.name)) || (" ");
    let pm = character.roles.find(r => ["name", "PM : 0", "PM : 1", "PM : 2", "PM : 3", "PM : 4", "PM : 5", "PM : 6", "PM : 7", "PM : 8", "PM : 9", "PM : 10"].includes(r.name)) || (" "); 
    let work = character.roles.find(r => ["name", "Elèves", "Professeurs", "Directeur de Poudlard", "Directeur Adjoint", "Concierges", "Surveillants", "Infirmièr(e)", "Bibliothécaire", "Garde-chasse", "Fantômes"].includes(r.name)) || (" ");
    let important = character.roles.find(r => ["name", "Rôlistes", "Spectateurs", "Sombral", "Personnel Magique"].includes(r.name)) || (" ");
    let important2 = character.roles.find(r => ["name", "Resp.Moderateurs", "MJ", "Scenariste", "Encadrant", "Moderateur", "Resp.Scenaristes", "Administrateur"].includes(r.name)) || (" ");
    let embedColor = character.displayColor

    //Eleves
    let house = character.roles.find(r => ["name", "Gryffondor", "Serpentard", "Poufsouffle", "Serdaigle"].includes(r.name)) || (" ");
    let prefet = character.roles.find(r =>["name", "Préfets"].includes(r.name)) || (" ");
    let club = character.roles.find(r => ["name", "Club de Chant"].includes(r.name)) || (" ");

    //Prof
    let dhouse = character.roles.find(r => ["name", "Directeur de maison"].includes(r.name)) || (" ");
    let matiere = character.roles.find(r => ["name", "DCFM", "Botanique", "Sortilèges", "Métamorphose", "Maître des potions", "Astronomie", "Histoire de la Magie", "Arithmancie", "Étude des runes", "Étude des Goules", "Étude des moldus", "Soin des créatures Magiques", "Alchimie", "Divination"].includes(r.name)) || (" ");

if (character.roles.some(r => ["name", "Elèves"].includes(r.name)) ) {
    const eleves = new Discord.RichEmbed()
    .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setColor(embedColor)
    .setFooter("Fiche descriptive de " + `${character.user.tag}`, character.user.avatarURL)
    .setImage(character.user.avatarURL)
    .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setTimestamp()
    .addBlankField(true)
    .addField("Pseudo", character.user.tag)
    .addField("Nom RP", character.nickname != undefined ? character.nickname : "Vous n'avez pas changer votre pseudo",true)
    .addField("Sexe", sexe.name != undefined ? sexe.name : "Non Définis", true)
    .addField("Sang", sang.name != undefined ? sang.name : "Non Définis", true)
    .addField("Race", race.name != undefined ? race.name : "Non Définis", true)
    .addField("Faculté RP", fac.name != undefined ? fac.name : "N'a aucune faculté RP", true)
    .addField("Métier", work.name != undefined ? work.name : "Non Définis", true)
    .addField("Club", club.name != undefined ? club.name : "Vous n'avez pas de club.", true)
    .addField("Maison", house.name != undefined ? house.name : "Vous n'avez pas de maison.", true)
    .addField("Prefet", prefet.name != undefined ? prefet.name : "Vous n'êtes pas prefet.", true)
    .addField("Puissance Magique", pm.name != undefined ? pm.name : "Non Définis")
    .addField("=============================", "============================")
    .addField("\n__**ROLE HRP**__", "Les r\u00f4les HRP")
    .addField("R\u00f4le Principal", important.name != undefined ? important.name : "Aucun", true)
    .addField("R\u00f4le Secondaire", important2.name != undefined ? important2.name : "Aucun", true)

        return message.delete(1000) + message.channel.send({embed: eleves }) + console.log("Reponse: Fiche RP de " + character.user.tag + `\n---------------------------------------------------`)
  //Prof
} else
if (character.roles.some(r => ["name", "Professeurs"].includes(r.name)) ) {

    const prof = new Discord.RichEmbed()
    .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setColor(embedColor)
    .setFooter("Fiche descriptive de " + `${character.user.tag}`, character.user.avatarURL)
    .setImage(character.user.avatarURL)
    .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setTimestamp()
    .addBlankField(true)
    .addField("Pseudo", character.user.tag)
    .addField("Nom RP", character.nickname != undefined ? character.nickname : "Vous n'avez pas changer votre pseudo",true)
    .addField("Sexe", sexe.name != undefined ? sexe.name : "Non Définis", true)
    .addField("Sang", sang.name != undefined ? sang.name : "Non Définis", true)
    .addField("Race", race.name != undefined ? race.name : "Non Définis", true)
    .addField("Faculté RP", fac.name != undefined ? fac.name : "N'a aucune faculté RP", true)
    .addField("Métier", work.name != undefined ? work.name : "Non Définis", true)
    .addField("Matière ", matiere.name != undefined ? matiere.name : "Non Définis")
    .addField("Directeur de Maison", dhouse.name != undefined ? dhouse.name : "Vous n'êtes pas de directeur de maison.", true)
    .addField("Puissance Magique", pm.name != undefined ? pm.name : "Non Définis", true)
    .addField("=============================", "============================")
    .addField("\n__**ROLE HRP**__", "Les r\u00f4les HRP")
    .addField("R\u00f4le Principal", important.name != undefined ? important.name : "Aucun", true)
    .addField("R\u00f4le Secondaire", important2.name != undefined ? important2.name : "Aucun", true)

    return message.delete(1000) + message.channel.send({embed: prof }) + console.log("Reponse: Fiche RP de " + character.user.tag + `\n---------------------------------------------------`)
//Spec
} else
if (character.roles.some(r => ["name", "Spectateurs", "Sombral"].includes(r.name)) ) {

    const spec = new Discord.RichEmbed()
    .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setColor(embedColor)
    .setFooter("Fiche descriptive de " + `${character.user.tag}`, character.user.avatarURL)
    .setImage(character.user.avatarURL)
    .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setTimestamp()
    .addBlankField(true)
    .addField("Pseudo", character.user.tag)
    .addField("=============================", "============================")
    .addField("\n__**ROLE HRP**__", "Les r\u00f4les HRP")
    .addField("R\u00f4le Principal", important.name != undefined ? important.name : "Aucun", true)
    .addField("R\u00f4le Secondaire", important2.name != undefined ? important2.name : "Aucun", true)

    return message.delete(1000) + message.channel.send({embed: spec }) + console.log("Reponse: Fiche RP de " + character.user.tag + `\n---------------------------------------------------`)
//Adulte
} else
if(character.roles.some(r => ["name", "Directeur de Poudlard", "Directeur Adjoint", "Concierges", "Surveillants", "Infirmièr(e)", "Bibliothécaire", "Garde-chasse", "Fantômes"].includes(r.name))) {
    
    
    const adulte = new Discord.RichEmbed()
    .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setColor(embedColor)
    .setFooter("Fiche descriptive de " + `${character.user.tag}`, character.user.avatarURL)
    .setImage(character.user.avatarURL)
    .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setTimestamp()
    .addBlankField(true)
    .addField("Pseudo", character.user.tag)
    .addField("Nom RP", character.nickname != undefined ? character.nickname : "Vous n'avez pas changer votre pseudo",true)
    .addField("Sexe", sexe.name != undefined ? sexe.name : "Non Définis", true)
    .addField("Sang", sang.name != undefined ? sang.name : "Non Définis", true)
    .addField("Race", race.name != undefined ? race.name : "Non Définis", true)
    .addField("Faculté RP", fac.name != undefined ? fac.name : "N'a aucune faculté RP", true)
    .addField("Métier", work.name != undefined ? work.name : "Non Définis", true)
    .addField("Puissance Magique", pm.name != undefined ? pm.name : "Non Définis", true)
    .addField("=============================", "============================")
    .addField("\n__**ROLE HRP**__", "Les r\u00f4les HRP")
    .addField("R\u00f4le Principal", important.name != undefined ? important.name : "Aucun", true)
    .addField("R\u00f4le Secondaire", important2.name != undefined ? important2.name : "Aucun", true)

    return message.delete(1000) + message.channel.send({embed: adulte }) + console.log("Reponse: Fiche RP de " + character.user.tag + `\n---------------------------------------------------`)
//Sans Grade
} else
  message.delete(1000) + message.channel.send("Erreur\nVous n'avez pas de grade.")

    } else
return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}