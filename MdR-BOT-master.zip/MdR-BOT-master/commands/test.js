exports.run = (client, message, args) => {
    message.delete(1000)
    message.channel.sendMessage("Ok :white_check_mark: ")
}