const Discord = require('discord.js')
const fs = require('fs')
const fileExists = require('file-exists')
const config = require('../config.json')

exports.run = (client, message) => {

    if (message.guild.id == "333359639385210881") {

  const playerFilePathA = `./players/${message.author.id}.json`
  fileExists(playerFilePathA).then(exists => {
    if (!exists) return message.delete(1000) + message.channel.send('**Vous n\'êtes pas enregistré.**')

    if (exists) {
        fs.unlink(playerFilePathA, (err) => {
            if (err) throw err
            if (!err) {

              message.guild.channels.find("name", "mod-log").send('**Éxécuteur :** ' + message.author.username + ' (' + message.author.id + ')\n**Channel :** ' + message.channel.name + ' (' + message.channel.id + ')\n**Envoi :** ' + message.createdAt.toString() + '\n**Commande :** ' + message.content)

                            //OutPut
    const output = new Discord.RichEmbed()
                .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                .setColor(0xFF0000)
                .setFooter("Fiche descriptive de " , client.user.avatarURL)
                .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                .setTimestamp()
                .addBlankField(true)
                .addField("Commande", message.content)
                .addField("Éxécuteur", message.author.username, true)
                .addField("Channel", message.channel.name)
                .addField("Date", message.createdAt.toString())
    
    client.channels.get("431238767471230976").send({embed: output});
        return message.delete(1000) + message.channel.send('**Vous vous êtes unregister avec succès.**')   
            }
        })
    }
  })
} else
return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.");
}