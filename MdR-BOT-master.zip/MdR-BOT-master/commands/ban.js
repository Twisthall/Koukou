const Discord = require('discord.js')

exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

            //Perm
    if (!message.member.hasPermission('BAN_MEMBERS')) {
        return message.delete(1000) + message.reply("Vous ne disposez pas de la permission.")

    }

            //Mention
        let ban = message.mentions.members.first();

        if (!ban)
        return message.reply("Merci de mentionner une personne.")

            //Id
        if (ban.id = "205067571127386113") return message.delete(1000) + message.channel.send("Erreur.\nVous ne pouvez pas ban <@!205067571127386113>.")

           
        if (!ban.kickable)
        return message.delete(1000) + message.reply("Erreur.")

            //Raison
        let raison = args.slice(1).join(' ');
    if (!raison) return message.delete(1000) + message.reply("Merci de mettre une raison.")

            //Ban + Catch Error
        ban.ban().then((ban))
            .catch(error => message.delete(1000) + message.reply(`Desole ${message.author} Je ne peux pas le ban : ${error}`))

            //Ban + Message        
        message.delete(1000)
            .then(ban.sendMessage("Vous avez été banni pour la raison : __" + raison + "__"));

        message.guild.channels.find("name", "hrp").send(`**${ban.user} a ete ban pour la raison :** __` + raison + "__")
        message.guild.channels.find("name", "mod-log").send(`**BAN**\n**User :** ${ban.user}\n **Raison :** __` +  raison + `__\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)
        
        //OutPut
    const output = new Discord.RichEmbed()
                .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                .setColor(0xFF0000)
                .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                .setTimestamp()
                .addBlankField(true)
                .addField("Commande", message.content)
                .addField("Éxécuteur", message.author.username, true)
                .addField("Cible", ban.user, true)
                .addField("Channel", message.channel.name)
                .addField("Date", message.createdAt.toString())

        client.channels.get("431238767471230976").send({embed: output});

    } else
    return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}