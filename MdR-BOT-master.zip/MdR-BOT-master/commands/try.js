const Discord = require('discord.js')
exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

    } else
return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}