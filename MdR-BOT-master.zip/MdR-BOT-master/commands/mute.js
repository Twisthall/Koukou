const config = require('../config.json')
const Discord = require('discord.js')

exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

            if (!message.member.hasPermission('KICK_MEMBERS')) {
                return message.delete(1000) + message.reply("Vous ne disposez pas de la permission.")
            }

            let rolem = message.guild.roles.find("name", "Muted");
            let mute = message.mentions.members.first();

            if (!mute)
                return message.delete(1000) + message.reply("Merci de mentionner quelqu'un");

            let muted = mute.roles.some(r => ["Muted"].includes(r.name));
    
        if (!muted) {

            let raisonm = args.slice(1).join(' ');

            if (!raisonm)
                return message.delete(1000) + message.reply("Merci de mettre une raison.")

            message.delete(1000)
            mute.addRole(rolem).catch(console.error);
            message.guild.channels.find("name", "hrp").send(`**${mute.user}, vous avez ete mute pour la raison :** __${raisonm}__`)
            message.guild.channels.find("name", "mod-log").send(`**MUTE**\n**User :** ${mute.user}\n**Raison :** ${raisonm}\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)

    //OutPut
    const output = new Discord.RichEmbed()
    .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setColor(0x000000)
    .setFooter("Fiche descriptive de " , client.user.avatarURL)
    .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setTimestamp()
    .addBlankField(true)
    .addField("Commande", message.content)
    .addField("Éxécuteur", message.author.username, true)
    .addField("Cible", mute.user, true)
    .addField("Channel", message.channel.name)
    .addField("Date", message.createdAt.toString())
    client.channels.get("431238767471230976").send({embed: output});

    } else
    return message.delete(1000) + message.channel.send("**Cette personne est deja mute !**");

    } else
        return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}