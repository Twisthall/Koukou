const Discord = require('discord.js')

exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {
    
    if (!message.member.hasPermission('KICK_MEMBERS')) {
        return message.delete(1000) + message.reply("Vous ne disposez pas de la permission.")
        }
    
    let roles = message.guild.roles.find("name", "@everyone");

    message.delete(1000)
    message.channel.overwritePermissions(roles, {
        SEND_MESSAGES: true,
    })
    message.guild.channels.find("name", "mod-log").send(`**UNMUTE-CHANNEL**\n**Channel :** ${message.channel.name}\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)
    message.channel.sendMessage("**Le channel a \351t\351 unmute.**")

        //OutPut
        const output = new Discord.RichEmbed()
        .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
        .setColor(0x00FF00)
        .setFooter("Fiche descriptive de " , client.user.avatarURL)
        .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
        .setTimestamp()
        .addBlankField(true)
        .addField("Commande", message.content)
        .addField("Éxécuteur", message.author.username, true)
        .addField("Channel", message.channel.name)
        .addField("Date", message.createdAt.toString())
        client.channels.get("431238767471230976").send({embed: output})
        .then(r => console.log(`Channel unMute`))
        .catch(console.error);
    } else
        return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}