exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

    if (!message.member.hasPermission('ADMINISTRATOR')) {
        return message.reply("Vous ne disposez pas de la permission.")
            .then(message => console.log(`Reponse: ${message} \n---------------------------------------------------`))
          }
    let i = args.slice(0).join(' ');
    message.delete(1000)
message.guild.channels.find("name", "bot").send( i + "\n@everyone")
    } else
        return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}