const fs = require('fs')
const fileExists = require('file-exists')

exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

        const PoufsouffleM = `../maison/Poufsouffle.json`
        const PoufsouffleH = `./maison/Poufsouffle.json`

        delete require.cache[require.resolve(PoufsouffleM)]

        const PoufsouffleP = require(PoufsouffleM)

        var pouf = PoufsouffleP;        


        const SerdaigleM = `../maison/Serdaigle.json`
        const SerdaigleH = `./maison/Serdaigle.json`

        delete require.cache[require.resolve(SerdaigleM)]

        const SerdaigleP = require(SerdaigleM)

        var serd = SerdaigleP;

        var SerpentardM = `../maison/Serpentard.json`
        var SerpentardH = `./maison/Serpentard.json`

        delete require.cache[require.resolve(SerpentardM)]

        const SerpentardP =  require(SerpentardM)

        var serp = SerpentardP;

        const GryffondorM = `../maison/Gryffondor.json`
        const GryffondorH = `./maison/Gryffondor.json`

        delete require.cache[require.resolve(GryffondorM)]

        const GryffondorP = require(GryffondorM)

        var gryf = GryffondorP
    

        let house1 = message.guild.roles.find("name", "/")
        let house2 = message.guild.roles.find("name", "/")
        let house3 = message.guild.roles.find("name", "/")
        let house4 = message.guild.roles.find("name", "/")
  
      
      let embedColor = 0x730284
        
            let score1 = 0
            let score2 = 0
            let score3 = 0
            let score4 = 0

            let perm = message.member.roles.find("name", "Professeur") || message.member.roles.find("name", "Developpeur") || message.member.roles.find("name", "Resp.Moderateurs") || message.member.roles.find("name", "Resp.Encadrement") || message.member.roles.find("name", "Moderateur") || message.member.roles.find("name", "MJ") || message.member.roles.find("name", "Administrateur"); 
        

        if (args[0] == 'add') {

        let nbr = Number(args[2])

        if (!perm) {
            message.delete(1000)
            message.reply("PERMISSION")
                } else

        if (nbr != parseInt(nbr, 10)) {
            message.delete(1000)
            message.reply("Nombre Invalide.\n__**RAPPEL**__\n\n`%point add Poufsouffle/Serdaigle/Serpentard/Gryffondor (nombre)` \n __**Exemple**__\n\n`%point add Poufsouffle 20`")
                } else 

        if (args[1] == "Poufsouffle") {

            pouf += nbr
                fs.writeFile(PoufsouffleH, JSON.stringify(pouf), (err) => console.error)

                message.delete(1000)
                message.channel.send("Ajout de `" + nbr + "` a **" + args[1] + "**.")
                message.guild.channels.find("name", "point-log").send(`**Add Point**\n**Maison :** ${args[1]}\n **Point :** __` + nbr + `__\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)


        } else if (args[1] == "Serdaigle") {

            serd += nbr
                fs.writeFile(SerdaigleH, JSON.stringify(serd), (err) => console.error)

                message.delete(1000)
                message.channel.send("Ajout de `" + nbr + "` a **" + args[1] + "**.")
                message.guild.channels.find("name", "point-log").send(`**Add Point**\n**Maison :** ${args[1]}\n **Point :** __` + nbr + `__\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)


        } else if (args[1] == "Serpentard") {

            serp += nbr
                fs.writeFile(SerpentardH, JSON.stringify(serp), (err) => console.error)

                message.delete(1000)
                message.channel.send("Ajout de `" + nbr + "` a **" + args[1] + "**.")
                message.guild.channels.find("name", "point-log").send(`**Add Point**\n**Maison :** ${args[1]}\n **Point :** __` + nbr + `__\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)

        } else if (args[1] == "Gryffondor") {

            gryf += nbr
                fs.writeFile(GryffondorH, JSON.stringify(gryf), (err) => console.error)

                message.delete(1000)
                message.channel.send("Ajout de `" + nbr + "` a **" + args[1] + "**.")
                message.guild.channels.find("name", "point-log").send(`**Add Point**\n**Maison :** ${args[1]}\n **Point :** __` + nbr + `__\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)

        } else

        message.delete(1000) + message.reply("Maison Invalide. \n\n - `Poufsouffle` \n - `Serdaigle`\n - `Serpentard`\n - `Gryffondor`\n\n*(Merci de reprendre exactement la même orthographe, **n'oubliez pas la majuscule**.)*")

    
    } else if (args[0] == 'remove') {

        let nbr = Number(args[2])

        if (!perm) {
            message.delete(1000)
            message.reply("PERMISSION")
        } else

        if (nbr != parseInt(nbr, 10)) {
            message.delete(1000)
            message.reply("Nombre Invalide.\n__**RAPPEL**__\n\n`%point remove Poufsouffle/Serdaigle/Serpentard/Gryffondor (nombre)` \n __**Exemple**__\n\n`%point remove Poufsouffle 20`")
                } else 

        if (args[1] == "Poufsouffle") {

            pouf -= nbr
                fs.writeFile(PoufsouffleH, JSON.stringify(pouf), (err) => console.error)

                message.delete(1000)
                message.channel.send("Retrait de `" + nbr + "` a **" + args[1] + "**.")
                message.guild.channels.find("name", "point-log").send(`**Remove Point**\n**Maison :** ${args[1]}\n **Point :** __` + nbr + `__\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)


        } else if (args[1] == "Serdaigle") {

            serd -= nbr
                fs.writeFile(SerdaigleH, JSON.stringify(serd), (err) => console.error)

                message.delete(1000)
                message.channel.send("Retrait de `" + nbr + "` a **" + args[1] + "**.")
                message.guild.channels.find("name", "point-log").send(`**Remove Point**\n**Maison :** ${args[1]}\n **Point :** __` + nbr + `__\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)


        } else if (args[1] == "Serpentard") {

            serp -= nbr
                fs.writeFile(SerpentardH, JSON.stringify(serp), (err) => console.error)

                message.delete(1000)
                message.channel.send("Retrait de `" + nbr + "` a **" + args[1] + "**.")
                message.guild.channels.find("name", "point-log").send(`**Remove Point**\n**Maison :** ${args[1]}\n **Point :** __` + nbr + `__\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)

        } else if (args[1] == "Gryffondor") {

            gryf -= nbr
                fs.writeFile(GryffondorH, JSON.stringify(gryf), (err) => console.error)

                message.delete(1000)
                message.channel.send("Retrait de `" + nbr + "` a **" + args[1] + "**.")
                message.guild.channels.find("name", "point-log").send(`**Remove Point**\n**Maison :** ${args[1]}\n **Point :** __` + nbr + `__\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)

        } else

        return message.delete(1000) + message.reply("Maison Invalide. \n\n - `Poufsouffle` \n - `Serdaigle`\n - `Serpentard`\n - `Gryffondor`\n\n*(Merci de reprendre exactement la même orthographe)*")



    } else if (args[0] == 'reset') {


        if (!message.member.hasPermission('ADMINISTRATOR')) {
            message.reply("PERMISSION")
        } else

        pouf = 0
            fs.writeFile(PoufsouffleH, JSON.stringify(pouf), (err) => console.error)

        serd = 0
            fs.writeFile(SerdaigleH, JSON.stringify(serd), (err) => console.error)

        serp = 0
            fs.writeFile(SerpentardH, JSON.stringify(serp), (err) => console.error)

        gryf = 0
            fs.writeFile(GryffondorH, JSON.stringify(gryf), (err) => console.error)

        message.delete(1000)
        message.channel.send("**Tous les points ont bien été réinitialisés**")
        message.guild.channels.find("name", "point-log").send(`**Reset Point**\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)


    } else if (args[0] == undefined) {

      //HOUSE 1
      if (pouf >= serd && pouf >= serp && pouf >= gryf) {
        house1 = message.guild.roles.find("name", "Poufsouffle")
        score1 = pouf
        embedColor = 0xfff109
        pouf = 0
      } else if (serd >= pouf && serd >= serp && serd >= gryf) {
        house1 = message.guild.roles.find("name", "Serdaigle")
        score1 = serd
        embedColor = 0x4369fc
        serd = 0
      } else if (serp >= serd && serp >= pouf && serp >= gryf) {
        house1 = message.guild.roles.find("name", "Serpentard")
        score1 = serp
        embedColor = 0x0b6300
        serp = 0
      } else if (gryf >= serd && gryf >= serp && gryf >= pouf) {
        house1 = message.guild.roles.find("name", "Gryffondor")
        score1 = gryf
        embedColor = 0xf70207
        gryf = 0
      }
  
      //HOUSE 2
     if (pouf >= serd && pouf >= serp && pouf >= gryf) {
        house2 = message.guild.roles.find("name", "Poufsouffle")
        score2 = pouf
        pouf = 0
      } else if (serd >= pouf && serd >= serp && serd >= gryf) {
        house2 = message.guild.roles.find("name", "Serdaigle")
        score2 = serd
        serd = 0
      } else if (serp >= serd && serp >= pouf && serp >= gryf) {
        house2 = message.guild.roles.find("name", "Serpentard")
        score2 = serp
        serp = 0
      } else if (gryf >= serd && gryf >= serp && gryf >= pouf) {
        house2 = message.guild.roles.find("name", "Gryffondor")
        score2 = gryf
        gryf = 0
      }
  
      //HOUSE 3
       if (pouf >= serd && pouf >= serp && pouf >= gryf) {
        house3 = message.guild.roles.find("name", "Poufsouffle")
        score3 = pouf
        pouf = 0
      } else if (serd >= pouf && serd >= serp && serd >= gryf) {
        house3 = message.guild.roles.find("name", "Serdaigle")
        score3 = serd
        serd = 0
      } else if (serp >= serd && serp >= pouf && serp >= gryf) {
        house3 = message.guild.roles.find("name", "Serpentard")
        score3 = serp
        serp = 0
      } else if (gryf >= serd && gryf >= serp && gryf >= pouf) {
        house3 = message.guild.roles.find("name", "Gryffondor")
        score3 = gryf
        gryf = 0
      }
  
      //HOUSE 4
      if (pouf >= serd && pouf >= serp && pouf >= gryf) {
        house4 = message.guild.roles.find("name", "Poufsouffle")
        score4 = pouf
        pouf = 0
      } else if (serd >= pouf && serd >= serp && serd >= gryf) {
        house4 = message.guild.roles.find("name", "Serdaigle")
        score4 = serd
        serd = 0
      } else if (serp >= serd && serp >= pouf && serp >= gryf) {
        house4 = message.guild.roles.find("name", "Serpentard")
        score4 = serp
        serp = 0
      } else if (gryf >= serd && gryf >= serp && gryf >= pouf) {
        house4 = message.guild.roles.find("name", "Gryffondor")
        score4 = gryf
        gryf = 0
      }

            message.delete(1000) + message.channel.send({embed: {
                author: {
                  name: client.user.username,
                  icon_url: client.user.avatarURL
                },
                title: "Points des maisons.",
                description: `===================`,
                color: embedColor,
                fields: [{
                    name: house1.name,
                    value: score1
                  },
                  {
                    name: house2.name,
                    value: score2
                  },
                  {
                    name: house3.name,
                    value: score3
                  },
                  {
                    name: house4.name,
                    value: score4
                  },
                  {
                    name: "===================",
                    value: `Les ${house1} sont premier avec ${score1} points.`
                  }
                ],
                timestamp: new Date(),
                footer: {
                  icon_url: client.user.avatarURL,
                  text: "Date"
                }
              }
    
            });
    } else if(args[0] == 'print') {

      if (!message.member.hasPermission('ADMINISTRATOR')) {
        message.delete(1000)
        message.reply("PERMISSION")
      } else
        message.channel.send(`pouf = ${pouf}\nserd = ${serd}\nserp = ${serp}\ngryf = ${gryf}`)
    } else if(args[0] == 'publish') {

      if (!perm) {
        message.delete(1000)
        message.reply("PERMISSION")
    } else


          //HOUSE 1
          if (pouf >= serd && pouf >= serp && pouf >= gryf) {
            house1 = message.guild.roles.find("name", "Poufsouffle")
            score1 = pouf
            embedColor = 0xfff109
            pouf = 0
          } else if (serd >= pouf && serd >= serp && serd >= gryf) {
            house1 = message.guild.roles.find("name", "Serdaigle")
            score1 = serd
            embedColor = 0x4369fc
            serd = 0
          } else if (serp >= serd && serp >= pouf && serp >= gryf) {
            house1 = message.guild.roles.find("name", "Serpentard")
            score1 = serp
            embedColor = 0x0b6300
            serp = 0
          } else if (gryf >= serd && gryf >= serp && gryf >= pouf) {
            house1 = message.guild.roles.find("name", "Gryffondor")
            score1 = gryf
            embedColor = 0xf70207
            gryf = 0
          }
      
          //HOUSE 2
         if (pouf >= serd && pouf >= serp && pouf >= gryf) {
            house2 = message.guild.roles.find("name", "Poufsouffle")
            score2 = pouf
            pouf = 0
          } else if (serd >= pouf && serd >= serp && serd >= gryf) {
            house2 = message.guild.roles.find("name", "Serdaigle")
            score2 = serd
            serd = 0
          } else if (serp >= serd && serp >= pouf && serp >= gryf) {
            house2 = message.guild.roles.find("name", "Serpentard")
            score2 = serp
            serp = 0
          } else if (gryf >= serd && gryf >= serp && gryf >= pouf) {
            house2 = message.guild.roles.find("name", "Gryffondor")
            score2 = gryf
            gryf = 0
          }
      
          //HOUSE 3
           if (pouf >= serd && pouf >= serp && pouf >= gryf) {
            house3 = message.guild.roles.find("name", "Poufsouffle")
            score3 = pouf
            pouf = 0
          } else if (serd >= pouf && serd >= serp && serd >= gryf) {
            house3 = message.guild.roles.find("name", "Serdaigle")
            score3 = serd
            serd = 0
          } else if (serp >= serd && serp >= pouf && serp >= gryf) {
            house3 = message.guild.roles.find("name", "Serpentard")
            score3 = serp
            serp = 0
          } else if (gryf >= serd && gryf >= serp && gryf >= pouf) {
            house3 = message.guild.roles.find("name", "Gryffondor")
            score3 = gryf
            gryf = 0
          }
      
          //HOUSE 4
          if (pouf >= serd && pouf >= serp && pouf >= gryf) {
            house4 = message.guild.roles.find("name", "Poufsouffle")
            score4 = pouf
            pouf = 0
          } else if (serd >= pouf && serd >= serp && serd >= gryf) {
            house4 = message.guild.roles.find("name", "Serdaigle")
            score4 = serd
            serd = 0
          } else if (serp >= serd && serp >= pouf && serp >= gryf) {
            house4 = message.guild.roles.find("name", "Serpentard")
            score4 = serp
            serp = 0
          } else if (gryf >= serd && gryf >= serp && gryf >= pouf) {
            house4 = message.guild.roles.find("name", "Gryffondor")
            score4 = gryf
            gryf = 0
          }
          

      message.delete(1000)
      message.guild.channels.find("name", "point-maison").send({embed: {
        author: {
          name: client.user.username,
          icon_url: client.user.avatarURL
        },
        title: "Points des maisons.",
        description: `Cours de ${message.author}`,
        color: embedColor,
        fields: [{
            name: house1.name,
            value: score1
          },
          {
            name: house2.name,
            value: score2
          },
          {
            name: house3.name,
            value: score3
          },
          {
            name: house4.name,
            value: score4
          },
          {
            name: "===================",
            value: `Les ${house1} sont premier avec ${score1} points.`
          }
        ],
        timestamp: new Date(),
        footer: {
          icon_url: client.user.avatarURL,
          text: "Date"
        }
      }

    });

        } else 
            return message.delete(1000) + message.channel.send("Erreur, faite `%help point` pour plus d'information.")
    } else
        return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}