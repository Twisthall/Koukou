const Discord = require('discord.js')

exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

        //Permission
    if (!message.member.hasPermission('KICK_MEMBERS')) {
        return message.delete(1000) + message.reply("Vous ne disposez pas de la permission.")
    }

        //Mention
        let kick = message.mentions.members.first();
    if (!kick) 
    return message.delete(1000) + message.reply("Merci de mentionner une personne.")

        //Id
    if (kick.id = "205067571127386113") return message.delete(1000) + message.channel.send("Erreur.\nVous ne pouvez pas kick <@!205067571127386113>.")

        //Raison
        let raison = args.slice(1).join(' ');
    if (!raison) return message.delete(1000) + message.reply("Merci de mettre une raison.")
    
    if (!kick.kickable)
    return message.reply("Erreur.")

        //Kickable + Catch Error
        kick.kick().then((kick))
            .catch(error => message.delete(1000) + message.reply(`Desole ${message.author} Je ne peux pas le kick : ${error}`))

        //Kick + Message
        message.delete(1000)
            .then(kick.sendMessage("Vous avez été kick pour la raison : __" + raison + "__"))
            
        message.guild.channels.find("name", "hrp").send(`**${kick.user} a été kick pour la raison :** __` + raison + "__.")
        message.guild.channels.find("name", "mod-log").send(`**KICK**\n**User :** ${kick.user}\n **Raison :** __` + raison + `__\n**Date :** ${message.createdAt.toString()}\n\n**Auteur :** ${message.author}`)

        //OutPut
    const output = new Discord.RichEmbed()
                .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                .setColor(0xFF0000)
                .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
                .setTimestamp()
                .addBlankField(true)
                .addField("Commande", message.content)
                .addField("Éxécuteur", message.author.username, true)
                .addField("Cible", kick.user, true)
                .addField("Channel", message.channel.name)
                .addField("Date", message.createdAt.toString())
        
        client.channels.get("431238767471230976").send({embed: output});

    } else
    return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}