exports.run = (client, message, args) => {
    if (message.guild.id == "333359639385210881") {
        let afkR = message.guild.roles.find("name", "AFK");
        let afkU = message.member.roles.find(r => ["AFK"].includes(r.name));
        if (!afkU) {
            message.member.addRole(afkR)
                .catch(error => console.log(error));
            message.delete(1000);
            message.channel.sendMessage(`**[${message.author} est maintenant AFK]**`);
            message.author.sendMessage(`**${message.author}` + " n'oublie pas de faire la commande `%afk` a ton retour !**");
        }
        else if (afkU) {
            message.member.removeRole(afkR)
                .catch(error => console.log(error));
            message.delete(1000);
            message.channel.sendMessage(`**[${message.author} n'est maintenant plus AFK]**`);
        }
        else
            message.delete(1000) + message.channel.send("Error");
    }
    else
        return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.");
}