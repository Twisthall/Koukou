const Discord = require('discord.js')
const config = require('../config.json')
const fs = require('fs')
const fileExists = require('file-exists')

exports.run = (client, message, args) => {

    if (message.guild.id == "333359639385210881") {

    if(!message.member.roles.some(r=>["→ [ACHIEVEMENT MdR] ←"].includes(r.name))) {
        let arole = message.guild.roles.find("name", "→ [ACHIEVEMENT MdR] ←");
        message.member.addRole(arole).catch(console.error);
        message.delete(1000)
   }
    if (!args[0]) return message.delete(1000) + message.channel.send("**Merci de sp\351cifier une actions\n `%ach list` pour voir les différentes commandes.**")   
if (args[0] == 'list') {
            message.delete(1000)
            return message.channel.send('**Les différente commande :**\n "`%ach give @user id`", "`%ach remove @user id`, "`%ach clear @user`" "`%ach show @user`", "`%ach refresh`"')
          } else
if (args[0] == 'show') {
  let show = message.mentions.members.first();
  if (!show) return message.delete(1000) + message.reply("Merci de mentionner une personne.")
  
  if (!show.roles.some(r=>["→ [ACHIEVEMENT MdR] ←"].includes(r.name))) {
    let arole = message.guild.roles.find("name", "→ [ACHIEVEMENT MdR] ←");
    message.member.addRole(arole);
  }

      let role1 = show.roles.find(r => ["name", "WORST ADMIN 2018"].includes(r.name)) || (" ");
      let role2 = show.roles.find(r => ["name", "Survivant de Hunter"].includes(r.name)) || (" ");
      let role3 = show.roles.find(r => ["name", "C ki Rosier ?"].includes(r.name)) || (" ");
      let role4 = show.roles.find(r => ["name", "C ki la prof de vol ?"].includes(r.name)) || (" ");
      let role5 = show.roles.find(r => ["name", "C'est quand que tu pars ?"].includes(r.name)) || (" ");
      let role6 = show.roles.find(r => ["name", "Rei, c'est qui ?"].includes(r.name)) || (" ");
      let role7 = show.roles.find(r => ["name", "Gryffondorite"].includes(r.name)) || (" ");
      let role8 = show.roles.find(r => ["name", "Cinq dirlos pour cinq années !"].includes(r.name)) || (" ");
      let role9 = show.roles.find(r => ["name", "On wiki pas nooous !"].includes(r.name)) || (" ");
      let role10 = show.roles.find(r => ["name", "Verdo Cookies"].includes(r.name)) || (" ");
      let role11 = show.roles.find(r => ["name", "Always."].includes(r.name)) || (" ");
      let role12 = show.roles.find(r => ["name", "Elève Fantôme"].includes(r.name)) || (" ");
      let role13 = show.roles.find(r => ["name", "Chanteur de Mariah Carrey"].includes(r.name)) || (" ");
      let role14 = show.roles.find(r => ["name", "Drama"].includes(r.name)) || (" ");
      let role15 = show.roles.find(r => ["name", "#NoFilter"].includes(r.name)) || (" ");
      let role16 = show.roles.find(r => ["name", "Star Instagram"].includes(r.name)) || (" ");
      let role17 = show.roles.find(r => ["name", "Narcissique Révolu"].includes(r.name)) || (" ");
      let role18 = show.roles.find(r => ["name", "Corrompu Égocentrique"].includes(r.name)) || (" ");
      let role19 = show.roles.find(r => ["name", "AFK Salle des Profs"].includes(r.name)) || (" ");
      let role20 = show.roles.find(r => ["name", "AFK Sdb"].includes(r.name)) || (" ");
      let role21 = show.roles.find(r => ["name", "Porte ses cordes vocales"].includes(r.name)) || (" ");
      let role22 = show.roles.find(r => ["name", "D4rKS4suK3"].includes(r.name)) || (" ");
      let role23 = show.roles.find(r => ["name", "Kamikaze"].includes(r.name)) || (" ");
      let role24 = show.roles.find(r => ["name", "IT'S OVER 9000 !"].includes(r.name)) || (" ");
      let role25 = show.roles.find(r => ["name", "Gaz Moutarde."].includes(r.name)) || (" ");
      let role26 = show.roles.find(r => ["name", "Descendant de Ron Weasley."].includes(r.name)) || (" ");
      let role27 = show.roles.find(r => ["name", "Mouton"].includes(r.name)) || (" ");
      let role28 = show.roles.find(r => ["name", "Rajeu"].includes(r.name)) || (" ");
      let role29 = show.roles.find(r => ["name", "Viktime Boloss."].includes(r.name)) || (" ");
      let role30 = show.roles.find(r => ["name", "Bourge"].includes(r.name)) || (" ");
      let role31 = show.roles.find(r => ["name", "HOMERUN !"].includes(r.name)) || (" ");
      let role32 = show.roles.find(r => ["name", "Cupidon"].includes(r.name)) || (" ");
      let role33 = show.roles.find(r => ["name", "Malade Imaginaire"].includes(r.name)) || (" ");
      let role34 = show.roles.find(r => ["name", "LOU JAROU"].includes(r.name)) || (" ");
      let role35 = show.roles.find(r => ["name", "Petit Chanceux"].includes(r.name)) || (" ");
      let role36 = show.roles.find(r => ["name", "DESPERADOOOOOOS !"].includes(r.name)) || (" ");
      let role37 = show.roles.find(r => ["name", "Vaul2mor vas venire meu shairshay"].includes(r.name)) || (" ");
      let role38 = show.roles.find(r => ["name", "Erasmus"].includes(r.name)) || (" ");
      let role39 = show.roles.find(r => ["name", "Rebel(le)"].includes(r.name)) || (" ");
      let role40 = show.roles.find(r => ["name", "Osi nwar kela nui"].includes(r.name)) || (" ");

    const target = new Discord.RichEmbed()
    .setAuthor("Miroir Du Rised [BOT]", "https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .addField("Pseudo", show.user.tag)
    .addField("Nom RP", show.nickname != undefined ? show.nickname : "Vous n'avez pas changer votre pseudo")
    .setThumbnail("https://cdn.discordapp.com/attachments/380750468445503498/431883584316637184/logo.png")
    .setColor(0xFF0000)
    .addField("=====", role1.name != undefined ? role1.name : ":no_entry:", true)
    .addField("=====", role2.name != undefined ? role2.name : ":no_entry:", true)
    .addField("=====", role3.name != undefined ? role3.name : ":no_entry:", true)
    .addField("=====", role4.name != undefined ? role4.name : ":no_entry:", true)
    .addField("=====", role5.name != undefined ? role5.name : ":no_entry:", true)
    .addField("=====", role6.name != undefined ? role6.name : ":no_entry:", true)
    .addField("=====", role7.name != undefined ? role7.name : ":no_entry:", true)
    .addField("=====", role8.name != undefined ? role8.name : ":no_entry:", true)
    .addField("=====", role9.name != undefined ? role9.name : ":no_entry:", true)
    .addField("=====", role10.name != undefined ? role10.name : ":no_entry:", true)
    .addField("=====", role11.name != undefined ? role11.name : ":no_entry:", true)
    .addField("=====", role12.name != undefined ? role12.name : ":no_entry:", true)
    .addField("=====", role13.name != undefined ? role13.name : ":no_entry:", true)
    .addField("=====", role14.name != undefined ? role14.name : ":no_entry:", true)
    .addField("=====", role15.name != undefined ? role15.name : ":no_entry:", true)
    .addField("=====", role16.name != undefined ? role16.name : ":no_entry:", true)
    .addField("=====", role17.name != undefined ? role17.name : ":no_entry:", true)
    .addField("=====", role18.name != undefined ? role18.name : ":no_entry:", true)
    .addField("=====", role19.name != undefined ? role19.name : ":no_entry:", true)
    .addField("=====", role20.name != undefined ? role20.name : ":no_entry:", true)
    .addField("=====", role21.name != undefined ? role21.name : ":no_entry:", true)
    .addField("=====", role22.name != undefined ? role22.name : ":no_entry:", true)

    const target2 = new Discord.RichEmbed()

    .addField("=====", role23.name != undefined ? role23.name : ":no_entry:", true)
    .addField("=====", role24.name != undefined ? role24.name : ":no_entry:", true)
    .addField("=====", role25.name != undefined ? role25.name : ":no_entry:", true)
    .addField("=====", role26.name != undefined ? role26.name : ":no_entry:", true)
    .addField("=====", role27.name != undefined ? role27.name : ":no_entry:", true)
    .addField("=====", role28.name != undefined ? role28.name : ":no_entry:", true)
    .addField("=====", role29.name != undefined ? role29.name : ":no_entry:", true)
    .addField("=====", role30.name != undefined ? role30.name : ":no_entry:", true)
    .addField("=====", role31.name != undefined ? role31.name : ":no_entry:", true)
    .addField("=====", role32.name != undefined ? role32.name : ":no_entry:", true)
    .addField("=====", role33.name != undefined ? role33.name : ":no_entry:", true)
    .addField("=====", role34.name != undefined ? role34.name : ":no_entry:", true)
    .addField("=====", role35.name != undefined ? role35.name : ":no_entry:", true)
    .addField("=====", role36.name != undefined ? role36.name : ":no_entry:", true)
    .addField("=====", role37.name != undefined ? role37.name : ":no_entry:", true)
    .addField("=====", role38.name != undefined ? role38.name : ":no_entry:", true)
    .addField("=====", role39.name != undefined ? role39.name : ":no_entry:", true)
    .addField("=====", role40.name != undefined ? role40.name : ":no_entry:", true)
    .setColor(0xFF0000)
    .setFooter("Fiche descriptive de " + `${show.user.tag}`, show.user.avatarURL)
    .setTimestamp()
    .addBlankField(true)

    return message.delete(1000) + message.channel.send({embed: target }) + message.channel.send({embed: target2 });
} else
if (args[0] == 'remove') {
            if (!message.member.hasPermission('KICK_MEMBERS')) {
                return message.reply("Vous ne disposez pas de la permission.")
                  }

            let guser = message.mentions.members.first();
          if (!guser) return message.reply('Vous devez @mentionner une personne')
         
          if (!guser.roles.some(r=>["→ [ACHIEVEMENT MdR] ←"].includes(r.name))) {
            let arole = message.guild.roles.find("name", "→ [ACHIEVEMENT MdR] ←");
            message.member.addRole(arole).catch(console.error);
          }
            
            let nbr = Number(args[2])
            let role1 = message.guild.roles.find("name", "WORST ADMIN 2018")
            let role2 = message.guild.roles.find("name", "Survivant de Hunter")
            let role3 = message.guild.roles.find("name", "C ki Rosier ?")
            let role4 = message.guild.roles.find("name", "C ki la prof de vol ?")
            let role5 = message.guild.roles.find("name", "C'est quand que tu pars ?")
            let role6 = message.guild.roles.find("name", "Rei, c'est qui ?")
            let role7 = message.guild.roles.find("name", "Gryffondorite")
            let role8 = message.guild.roles.find("name", "Cinq dirlos pour cinq années !")
            let role9 = message.guild.roles.find("name", "On wiki pas nooous !")
            let role10 = message.guild.roles.find("name", "Verdo Cookies")
            let role11 = message.guild.roles.find("name", "Always.")
            let role12 = message.guild.roles.find("name", "Elève Fantôme")
            let role13 = message.guild.roles.find("name", "Chanteur de Mariah Carrey")
            let role14 = message.guild.roles.find("name", "Drama")
            let role15 = message.guild.roles.find("name", "#NoFilter")
            let role16 = message.guild.roles.find("name", "Star Instagram")
            let role17 = message.guild.roles.find("name", "Narcissique Révolu")
            let role18 = message.guild.roles.find("name", "Corrompu Égocentrique")
            let role19 = message.guild.roles.find("name", "AFK Salle des Profs")
            let role20 = message.guild.roles.find("name", "AFK Sdb")
            let role21 = message.guild.roles.find("name", "Porte ses cordes vocales")
            let role22 = message.guild.roles.find("name", "D4rKS4suK3")
            let role23 = message.guild.roles.find("name", "Kamikaze")
            let role24 = message.guild.roles.find("name", "IT'S OVER 9000 !")
            let role25 = message.guild.roles.find("name", "Gaz Moutarde.")
            let role26 = message.guild.roles.find("name", "Descendant de Ron Weasley.")
            let role27 = message.guild.roles.find("name", "Mouton")
            let role28 = message.guild.roles.find("name", "Rajeu")
            let role29 = message.guild.roles.find("name", "Viktime Boloss.")
            let role30 = message.guild.roles.find("name", "Bourge")
            let role31 = message.guild.roles.find("name", "HOMERUN !")
            let role32 = message.guild.roles.find("name", "Cupidon")
            let role33 = message.guild.roles.find("name", "Malade Imaginaire")
            let role34 = message.guild.roles.find("name", "LOU JAROU")
            let role35 = message.guild.roles.find("name", "DESPERADOOOOOOS !")
            let role36 = message.guild.roles.find("name", "Vaul2mor vas venire meu shairshay")
            let role37 = message.guild.roles.find("name", "Erasmus")
            let role38 = message.guild.roles.find("name", "Rebel(le)")

       if (nbr == "1") 
          return guser.removeRole(role1).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role1.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "2") 
          return guser.removeRole(role2).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role2.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "3") 
          return guser.removeRole(role3).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role3.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "4") 
          return guser.removeRole(role4).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role4.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "5") 
          return guser.removeRole(role5).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role5.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "6") 
          return guser.removeRole(role6).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role6.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "7") 
          return guser.removeRole(role7).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role7.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "8") 
          return guser.removeRole(role8).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role8.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "9") 
          return guser.removeRole(role9).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role9.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "10") 
          return guser.removeRole(role10).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role10.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "11") 
          return guser.removeRole(role11).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role11.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "12") 
          return guser.removeRole(role12).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role12.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "13") 
          return guser.removeRole(role13).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role13.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "14") 
          return guser.removeRole(role14).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role14.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "15") 
          return guser.removeRole(role15).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role15.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "16") 
          return guser.removeRole(role16).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role16.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "17") 
          return guser.removeRole(role17).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role17.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "18") 
          return guser.removeRole(role18).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role18.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "19") 
         return guser.removeRole(role19).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role19.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "20") 
         return guser.removeRole(role20).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role20.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "21") 
         return guser.removeRole(role21).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role21.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "22") 
         return guser.removeRole(role22).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role22.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "23") 
         return guser.removeRole(role23).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role23.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "24") 
         return guser.removeRole(role24).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role24.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "25") 
         return guser.removeRole(role25).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role25.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "26") 
         return guser.removeRole(role25).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role26.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "27") 
         return guser.removeRole(role27).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role27.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "28") 
         return guser.removeRole(role28).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role28.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "29") 
         return guser.removeRole(role29).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role29.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "30") 
         return guser.removeRole(role30).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role30.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "31") 
          return guser.removeRole(role31).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role31.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "32") 
          return guser.removeRole(role32).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role32.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "33") 
          return guser.removeRole(role33).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role33.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)  
       if (nbr == "35") 
          return guser.removeRole(role34).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role34.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "35") 
          return guser.removeRole(role34).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role35.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "36") 
          return guser.removeRole(role35).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role36.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "37") 
          return guser.removeRole(role36).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role37.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr == "38") 
          return guser.removeRole(role37).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach remove " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Remove :** " + role38.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
       if (nbr >= "38")
          message.reply("Il y a actuellement 36 achivements, leurs id correspond a leurs emplacement dans les rôles.")
        }
if (args[0] == 'give') {
              if (!message.member.hasPermission('KICK_MEMBERS')) {
                  return message.reply("Vous ne disposez pas de la permission.")
                    }
  
              let guser = message.mentions.members.first();
            if (!guser) return message.reply('Vous devez @mentionner une personne') 
            
            if (!guser.roles.some(r=>["→ [ACHIEVEMENT MdR] ←"].includes(r.name))) {
              let arole = message.guild.roles.find("name", "→ [ACHIEVEMENT MdR] ←");
              message.member.addRole(arole).catch(console.error);
            }
              
              let nbr = Number(args[2])
              let role1 = message.guild.roles.find("name", "WORST ADMIN 2018")
              let role2 = message.guild.roles.find("name", "Survivant de Hunter")
              let role3 = message.guild.roles.find("name", "C ki Rosier ?")
              let role4 = message.guild.roles.find("name", "C ki la prof de vol ?")
              let role5 = message.guild.roles.find("name", "C'est quand que tu pars ?")
              let role6 = message.guild.roles.find("name", "Rei, c'est qui ?")
              let role7 = message.guild.roles.find("name", "Gryffondorite")
              let role8 = message.guild.roles.find("name", "Cinq dirlos pour cinq années !")
              let role9 = message.guild.roles.find("name", "On wiki pas nooous !")
              let role10 = message.guild.roles.find("name", "Verdo Cookies")
              let role11 = message.guild.roles.find("name", "Always.")
              let role12 = message.guild.roles.find("name", "Elève Fantôme")
              let role13 = message.guild.roles.find("name", "Chanteur de Mariah Carrey")
              let role14 = message.guild.roles.find("name", "Drama")
              let role15 = message.guild.roles.find("name", "#NoFilter")
              let role16 = message.guild.roles.find("name", "Star Instagram")
              let role17 = message.guild.roles.find("name", "Narcissique Révolu")
              let role18 = message.guild.roles.find("name", "Corrompu Égocentrique")
              let role19 = message.guild.roles.find("name", "AFK Salle des Profs")
              let role20 = message.guild.roles.find("name", "AFK Sdb")
              let role21 = message.guild.roles.find("name", "Porte ses cordes vocales")
              let role22 = message.guild.roles.find("name", "D4rKS4suK3")
              let role23 = message.guild.roles.find("name", "Kamikaze")
              let role24 = message.guild.roles.find("name", "IT'S OVER 9000 !")
              let role25 = message.guild.roles.find("name", "Gaz Moutarde.")
              let role26 = message.guild.roles.find("name", "Descendant de Ron Weasley.")
              let role27 = message.guild.roles.find("name", "Mouton")
              let role28 = message.guild.roles.find("name", "Rajeu")
              let role29 = message.guild.roles.find("name", "Viktime Boloss.")
              let role30 = message.guild.roles.find("name", "Bourge")
              let role31 = message.guild.roles.find("name", "HOMERUN !")
              let role32 = message.guild.roles.find("name", "Cupidon")
              let role33 = message.guild.roles.find("name", "Malade Imaginaire")
              let role34 = message.guild.roles.find("name", "LOU JAROU")
              let role35 = message.guild.roles.find("name", "DESPERADOOOOOOS !")
              let role36 = message.guild.roles.find("name", "Vaul2mor vas venire meu shairshay")
              let role37 = message.guild.roles.find("name", "Erasmus")
              let role38 = message.guild.roles.find("name", "Rebel(le)")
            
  
         if (nbr == "1") 
            return guser.addRole(role1).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role1.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "2") 
            return guser.addRole(role2).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role2.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "3") 
            return guser.addRole(role3).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role3.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "4") 
            return guser.addRole(role4).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role4.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "5") 
            return guser.addRole(role5).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role5.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "6") 
            return guser.addRole(role6).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role6.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "7") 
            return guser.addRole(role7).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role7.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "8") 
            return guser.addRole(role8).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role8.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "9") 
            return guser.addRole(role9).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role9.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "10") 
            return guser.addRole(role10).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role10.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "11") 
            return guser.addRole(role11).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role11.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "12") 
            return guser.addRole(role12).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role12.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "13") 
            return guser.addRole(role13).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role13.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "14") 
            return guser.addRole(role14).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role14.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "15") 
            return guser.addRole(role15).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role15.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "16") 
            return guser.addRole(role16).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role16.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "17") 
            return guser.addRole(role17).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role17.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "18") 
            return guser.addRole(role18).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role18.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "19") 
           return guser.addRole(role19).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role19.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "20") 
           return guser.addRole(role20).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role20.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "21") 
           return guser.addRole(role21).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role21.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "22") 
           return guser.addRole(role22).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role22.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "23") 
           return guser.addRole(role23).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role23.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "24") 
           return guser.addRole(role24).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role24.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "25") 
           return guser.addRole(role25).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role25.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "26") 
           return guser.addRole(role25).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role26.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "27") 
           return guser.addRole(role27).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role27.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "28") 
           return guser.addRole(role28).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role28.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "29") 
           return guser.addRole(role29).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role29.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "30") 
           return guser.addRole(role30).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role30.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "31") 
            return guser.addRole(role31).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role31.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "32") 
            return guser.addRole(role32).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role32.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "33") 
            return guser.addRole(role33).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role33.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)  
         if (nbr == "34") 
            return guser.addRole(role34).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role34.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "35") 
            return guser.addRole(role34).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role35.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "36") 
            return guser.addRole(role35).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role36.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "37") 
            return guser.addRole(role36).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role37.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)
         if (nbr == "38") 
            return guser.addRole(role37).catch(console.error) + message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach give " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Achivement Give :** " + role38.name + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)          
         if (nbr >= "38")
         message.delete(1000)
          return message.reply("Il y a actuellement 38 achivements, leurs id correspond a leurs emplacement dans les rôles.")  
          } else
if (args[0] == 'clear') {
            if (!message.member.hasPermission('KICK_MEMBERS')) {
              return message.reply("Vous ne disposez pas de la permission.")
                }

          let guser = message.mentions.members.first();
        if (!guser) return message.reply('Vous devez @mentionner une personne') 
        
        if (!guser.roles.some(r=>["→ [ACHIEVEMENT MdR] ←"].includes(r.name))) {
          let arole = message.guild.roles.find("name", "→ [ACHIEVEMENT MdR] ←");
          message.member.addRole(arole).catch(console.error);
        }
              let role1 = message.guild.roles.find("name", "WORST ADMIN 2018")
              let role2 = message.guild.roles.find("name", "Survivant de Hunter")
              let role3 = message.guild.roles.find("name", "C ki Rosier ?")
              let role4 = message.guild.roles.find("name", "C ki la prof de vol ?")
              let role5 = message.guild.roles.find("name", "C'est quand que tu pars ?")
              let role6 = message.guild.roles.find("name", "Rei, c'est qui ?")
              let role7 = message.guild.roles.find("name", "Gryffondorite")
              let role8 = message.guild.roles.find("name", "Cinq dirlos pour cinq années !")
              let role9 = message.guild.roles.find("name", "On wiki pas nooous !")
              let role10 = message.guild.roles.find("name", "Verdo Cookies")
              let role11 = message.guild.roles.find("name", "Always.")
              let role12 = message.guild.roles.find("name", "Elève Fantôme")
              let role13 = message.guild.roles.find("name", "Chanteur de Mariah Carrey")
              let role14 = message.guild.roles.find("name", "Drama")
              let role15 = message.guild.roles.find("name", "#NoFilter")
              let role16 = message.guild.roles.find("name", "Star Instagram")
              let role17 = message.guild.roles.find("name", "Narcissique Révolu")
              let role18 = message.guild.roles.find("name", "Corrompu Égocentrique")
              let role19 = message.guild.roles.find("name", "AFK Salle des Profs")
              let role20 = message.guild.roles.find("name", "AFK Sdb")
              let role21 = message.guild.roles.find("name", "Porte ses cordes vocales")
              let role22 = message.guild.roles.find("name", "D4rKS4suK3")
              let role23 = message.guild.roles.find("name", "Kamikaze")
              let role24 = message.guild.roles.find("name", "IT'S OVER 9000 !")
              let role25 = message.guild.roles.find("name", "Gaz Moutarde.")
              let role26 = message.guild.roles.find("name", "Descendant de Ron Weasley.")
              let role27 = message.guild.roles.find("name", "Mouton")
              let role28 = message.guild.roles.find("name", "Rajeu")
              let role29 = message.guild.roles.find("name", "Viktime Boloss.")
              let role30 = message.guild.roles.find("name", "Bourge")
              let role31 = message.guild.roles.find("name", "HOMERUN !")
              let role32 = message.guild.roles.find("name", "Cupidon")
              let role33 = message.guild.roles.find("name", "Malade Imaginaire")
              let role34 = message.guild.roles.find("name", "LOU JAROU")
              let role35 = message.guild.roles.find("name", "DESPERADOOOOOOS !")
              let role36 = message.guild.roles.find("name", "Vaul2mor vas venire meu shairshay")
              let role37 = message.guild.roles.find("name", "Erasmus")
              let role38 = message.guild.roles.find("name", "Rebel(le)")

            let r = guser.removeRole(role1) + guser.removeRole(role2) + guser.removeRole(role3) + guser.removeRole(role4) + guser.removeRole(role5) + guser.removeRole(role6) + guser.removeRole(role7) + guser.removeRole(role8) + guser.removeRole(role9) + guser.removeRole(role10) + guser.removeRole(role11) + guser.removeRole(role12) + guser.removeRole(role13) + guser.removeRole(role14) + guser.removeRole(role15) + guser.removeRole(role16) + guser.removeRole(role17) + guser.removeRole(role18) + guser.removeRole(role19) + guser.removeRole(role20) + guser.removeRole(role21) + guser.removeRole(role22) + guser.removeRole(role23) + guser.removeRole(role24) + guser.removeRole(role25) + guser.removeRole(role26) + guser.removeRole(role27) + guser.removeRole(role28) + guser.removeRole(role29) + guser.removeRole(role30) + guser.removeRole(role31) + guser.removeRole(role32) + guser.removeRole(role33) + guser.removeRole(role34) + guser.removeRole(role35) + guser.removeRole(role36) + guser.removeRole(role37) + guser.removeRole(role38);
            for (r = 0; r < 38; r++) {
            return message.delete(1000) + message.channel.sendMessage(":ok:") + message.guild.channels.find("name", "mod-log").send("__**Achivement**__\n\n**Commande :** `%ach clear " + guser.nickname + "`\n**Target :** " + guser.user.tag + "\n**Date :** "  + message.createdAt.toString() + "\n\n**Éxécuteur :** " + message.author.username)          
            }
          } else
if (args[0] == 'refresh') {

  if (!message.member.roles.some(r=>["→ [ACHIEVEMENT MdR] ←"].includes(r.name))) {
    let arole = message.guild.roles.find("name", "→ [ACHIEVEMENT MdR] ←");
    message.member.addRole(arole).catch(console.error);
  }

            let role1 = message.guild.roles.find("name", "WORST ADMIN 2018")
            let role2 = message.guild.roles.find("name", "Survivant de Hunter")
            let role3 = message.guild.roles.find("name", "C ki Rosier ?")
            let role4 = message.guild.roles.find("name", "C ki la prof de vol ?")
            let role5 = message.guild.roles.find("name", "C'est quand que tu pars ?")
            let role6 = message.guild.roles.find("name", "Rei, c'est qui ?")
            let role7 = message.guild.roles.find("name", "Gryffondorite")
            let role8 = message.guild.roles.find("name", "Cinq dirlos pour cinq années !")
            let role9 = message.guild.roles.find("name", "On wiki pas nooous !")
            let role10 = message.guild.roles.find("name", "Verdo Cookies")
            let role11 = message.guild.roles.find("name", "Always.")
            let role12 = message.guild.roles.find("name", "Elève Fantôme")
            let role13 = message.guild.roles.find("name", "Chanteur de Mariah Carrey")
            let role14 = message.guild.roles.find("name", "Drama")
            let role15 = message.guild.roles.find("name", "#NoFilter")
            let role16 = message.guild.roles.find("name", "Star Instagram")
            let role17 = message.guild.roles.find("name", "Narcissique Révolu")
            let role18 = message.guild.roles.find("name", "Corrompu Égocentrique")
            let role19 = message.guild.roles.find("name", "AFK Salle des Profs")
            let role20 = message.guild.roles.find("name", "AFK Sdb")
            let role21 = message.guild.roles.find("name", "Porte ses cordes vocales")
            let role22 = message.guild.roles.find("name", "D4rKS4suK3")
            let role23 = message.guild.roles.find("name", "Kamikaze")
            let role24 = message.guild.roles.find("name", "IT'S OVER 9000 !")
            let role25 = message.guild.roles.find("name", "Gaz Moutarde.")
            let role26 = message.guild.roles.find("name", "Descendant de Ron Weasley.")
            let role27 = message.guild.roles.find("name", "Mouton")
            let role28 = message.guild.roles.find("name", "Rajeu")
            let role29 = message.guild.roles.find("name", "Viktime Boloss.")
            let role30 = message.guild.roles.find("name", "Bourge")
            let role31 = message.guild.roles.find("name", "HOMERUN !")
            let role32 = message.guild.roles.find("name", "Cupidon")
            let role33 = message.guild.roles.find("name", "Malade Imaginaire")
            let role34 = message.guild.roles.find("name", "LOU JAROU")
            let role35 = message.guild.roles.find("name", "DESPERADOOOOOOS !")
            let role36 = message.guild.roles.find("name", "Vaul2mor vas venire meu shairshay")
            let role37 = message.guild.roles.find("name", "Erasmus")
            let role38 = message.guild.roles.find("name", "Rebel(le)")

            if (message.member.roles.some(r=>["PM : 10"].includes(r.name)) ) {
              message.delete(1000)
              message.member.addRole(role24) + message.author.sendMessage(message.author + "Vous avez debloqué l'achivement **" + role24.name + "**")
            }

            if (message.member.roles.some(r=>["Club de Chant"].includes(r.name)) ) {
              message.delete(1000)
              message.member.addRole(role21) + message.author.sendMessage(message.author + "Vous avez debloqué l'achivement **" + role21.name + "**")
            }

            if (message.member.roles.find(r => ["Resp.Moderateurs", "MJ", "Scenariste", "Encadrant", "Moderateur", "Resp.Scenaristes", "Administrateur"].includes(r.name))) {
              message.delete(1000)
              message.member.addRole(role18) + message.author.sendMessage(message.author + "Vous avez debloqué l'achivement **" + role18.name + "**")
            }

            let warnedUser = message.author.id
            const userFilePath = `../players/${warnedUser}.json`
            const user = require(userFilePath)
            if (user.warns == 1) {
              message.delete(1000)
              message.member.addRole(role38) + message.author.sendMessage(message.author + "Vous avez debloqué l'achivement **" + role38.name + "\nEASTER EGG**")
            }
            message.channel.send(":ok:")
            
            }

             message.channel.sendMessage("**Commande invalide, faite `%ach list` pour voir les commandes disponible**")  
    } else
        return message.delete(1000) + message.reply("Vous ne pouvez pas utilisez cette commande ici.")
}